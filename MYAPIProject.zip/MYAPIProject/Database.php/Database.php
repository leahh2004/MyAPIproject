<?php
class Database {
    private $pdo;

    public function__construct() {
        try {
            // SQLite connection string
            $this->pdo = new PDO('sqlite:/path_to_your_database/chi2023.db'); // Adjust path as necessary
            $this->pdosetAttribute(PDO::ATTR_ERRMODE, PDO::ERRMOVE_EXCEPTION);
        } catch (PDOException $e) {
            // Handle errors during connection
            throw new Exception('Database connection failed: ' . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->pdo;
    }
}
?>