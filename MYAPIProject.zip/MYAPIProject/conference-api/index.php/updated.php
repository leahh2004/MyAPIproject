case "content":
    $controller = new ContentController();
    
    if ($id && isset($requestUri[2]) && $requestUri[2] === "award") {
        if ($requestMethod === "GET") {
            echo json_encode($controller->getAwardForContent($id));
        } elseif ($requestMethod === "POST") {
            $data = json_decode(file_get_contents("php://input"), true);
            echo json_encode($controller->assignAwardToContent($id, $data['award_id'] ?? null));
        } elseif ($requestMethod === "DELETE") {
            echo json_encode($controller->removeAwardFromContent($id));
        }
    }
    break;
