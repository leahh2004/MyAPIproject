<?php

require_once "../src/controllers/AwardController.php";

header("Content-Type: application/json");
$method = $_SERVER["REQUEST_METHOD"];
$request_uri = explode("/", trim($_SERVER["REQUEST_URI"], "/"));

if ($request_uri[0] === "award") {
    $controller = new AwardController();
    $controller->handleRequest($method);
} else {
    http_response_code(404);
    echo json_encode(["error" => "Endpoint not found"]);
}
?>
