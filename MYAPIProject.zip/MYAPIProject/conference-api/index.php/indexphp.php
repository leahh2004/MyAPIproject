<>php

// Include necessary file 
require_once 'db/Database.php'; // If you're using database connections
require_once 'helpers/HelperFunctions.php'; // (Optional) Any helpers you might need

// Get the requested URI and the HTTP method (GET, POST, etc.)
$requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH); // This gets the request path

// Route requests to the appropriate endpoint
switch ($requestURI) {
    case '/developer':
        if ($requestMethod == 'GET') {
            require_once 'endpoints/developer.php'; // Include the developer endpoint exception_handler
        } else {
            // If an invalid method is used, return 405 Method Not Allowed
            http_response_code(405);
            echo json_encode(["error" => "Method Not Allowed"]);
        }
        break;

    case '/content':
        if ($requestMethod == 'GET') {
            require_once 'endpoints/content.php'; // Include the content GET endpoint handler 
        } elseif ($requestMethod == 'POST') {
            require_once 'endpoints/content_post.php'; // Handle POSt requests for creating content 
        } else {
            http_response_code(405);
            echo json_encode(["error" => "Method Not Allowed"]);
        }
        break;

    case '/author':
        if ($requestMethod == 'GET') {
            require_once 'endpoints/author.php'; // Include the author GET endpoint handler 
        } else {
            http_response_code(405);
            echo json_encode(["error" => "Method Not Allowed"]);
        }
        break;

    default:
        // If no matching route is found, return a 404 Not Found responses
        http_response_code(404);
        echo json_encode(["error" => "Endpoint Not Found"]);
        break;
}
?>