<?php
// Include configuration, security middleware, and controllers
require_once "../config.php";
require_once "../middleware.php";
require_once "../src/controllers/ContentController.php";
require_once "../src/controllers/AuthorController.php";
require_once "../src/controllers/AwardController.php";

// Set response header for JSON output
header("Content-Type: application/json");

// Validate API key before proceeding
validateAPIKey();

// Get the request method (GET, POST, DELETE, etc)
$method = $_SERVER["REQUEST_METHOD"];

// Extract the endpoint from the URL
$request_uri = explode("/", trim($_SERVER["REQUEST_URI"], "/"));

// Route the request to the appropriate controller
if ($request_uri[0] === "content") {
    $controller = new ContentController();
    $controller->handleRequest($method);
} elseif ($request_uri[0] === "author") {
    $controller = new AuthorController();
    $controller->handleRequest(method);
} elseif ($request_uri[0] == "award") {
    $controller = new AwardController();
    $controller->handleRequest($method);
} else {
    // If the requested endpoint doesn't exist, return a 404 error
    http_response_code(404);
    echo json_encode(["error" => "Endpoint not found"]);
}
?>