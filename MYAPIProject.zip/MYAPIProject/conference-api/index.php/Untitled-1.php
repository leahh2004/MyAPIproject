<?php

// Enable CORS (for testing with Postman)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorisation");

// Load required files
require_once '../config.php';
require_once '../src/core/Router.php';

// Start the router
$router = new Router();
$router->handleRequest();