<?php
require_once 'controllers/ContentController.php';

// Get the requested endpoing from the URL
$request_uri = explode('/', trim($_SERVER['REQUEST_URI'], '/'));

// Extract the first part of the request (e.g., 'content')
$endpoint = strtolower($request_uri[0] ?? '');

// Get query parameters
$params = $_GET;

// Handle different endpoints
header("Content-Type: application/json"); // Ensure response is JSON
switch ($endpoint) {
    case'content':
        $controller = new ContentController();
        echo $controller->getContent($params);
        break

        default:
        http_response_code(404);
        echo json_encode(["error" => "Endpoint not found"]);
}