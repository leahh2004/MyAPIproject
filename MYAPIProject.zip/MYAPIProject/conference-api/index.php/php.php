<?php
require_once 'config/database.php'; // Database connection
require_once 'router.php'; // Handles request routing

// Get the request URI
$request = $_GET['request'] ?? '';

// Initialise the router and handle the request
$router = new Router();
$router->handleRequest($request);
?>