<?php
// Enable CORS (Allows API to be accessed from different origins)
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Load configuration and database connection
require_once "config.php";

// Get the request URL
$request_uri = $_GET['request'] ?? '';

// Define API routes
switch ($request_uri) {
    case "author":
        require_once "endpoints/author.php";
        break;
    case "content":
        require_once "endpoints/content.php";
        break;
    case "award":
        require_once "endpoints/award.php";
        break;
    default:
        http_response_code(404);
        echo json_encode(["message" => "Endpoint not found"]);
        break;
}
?>