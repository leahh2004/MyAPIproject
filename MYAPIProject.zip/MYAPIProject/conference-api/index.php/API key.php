<?php

// Include necessary files
require_once 'db/Database.php'; // Example DB connection class
require_once 'helpers/HelperFunctions.php'; // (Optional) Any helpers you might need
require_once 'config.php';  // Include the configuration where the API key is stored

// Get the requested URI and the HTTP method (GET, POST, etc.)
$requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);  
$requestMethod = $_SERVER['REQUEST_METHOD'];  

// Get the Authorization header from the request
$headers = getallheaders();
$authorization = isset($headers['Authorization']) ? $headers['Authorization'] : '';

// Check if the authorization key matches
if ($authorization !== API_KEY) {
    // If the key doesn't match, return an unauthorized response (401)
    http_response_code(401);  // Unauthorized
    echo json_encode(["error" => "Unauthorized, invalid API key"]);
    exit;
}

// Route the request to the appropriate endpoint
switch ($requestUri) {
    case '/developer':
        if ($requestMethod == 'GET') {
            require_once 'endpoints/developer.php';
        } else {
            http_response_code(405);  // Method Not Allowed
            echo json_encode(["error" => "Method Not Allowed"]);
        }
        break;

    case '/content':
        if ($requestMethod == 'GET') {
            require_once 'endpoints/content.php';  
        } elseif ($requestMethod == 'POST') {
            require_once 'endpoints/content_post.php'; 
        } else {
            http_response_code(405);  
            echo json_encode(["error" => "Method Not Allowed"]);
        }
        break;

    case '/author':
        if ($requestMethod == 'GET') {
            require_once 'endpoints/author.php';  
        } else {
            http_response_code(405);
            echo json_encode(["error" => "Method Not Allowed"]);
        }
        break;

    default:
        // 404 Not Found if no route matches
        http_response_code(404);
        echo json_encode(["error" => "Endpoint Not Found"]);
        break;
}
?>
