<?php
declare(strict_types=1);

require_once '.../src/core/Autoloader.php';
require_once '../config.php';

// Handle incoming requests
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = explode('/', trim($uri, '/'));

$controllerName = $uri[0] ?? 'default'; 
$action = $_SERVER['REQUEST_METHOD'];

$controllerClass = 'Controllers\\' . ucfirst($controllerName) . 'Controller';
if (class_exists($controllerClass)) {
    $controller = new $controlClass();
    $controller->handleRequest($action, $_GET);
} else {
    http_response_code(404);
    echo json_encode(["error" => "Endpoint not found"]);
}