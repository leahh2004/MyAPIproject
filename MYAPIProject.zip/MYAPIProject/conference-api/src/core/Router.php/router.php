<?php

class Router {
    public function handleRequest() {
        // Get the requested URL
        $url = isset($_GET['url']) ? explode('/', trim($_GET['url'], '/')) : [];

        // Extract the controller name from the URL
        $controllerName = !empty($url[0]) ? ucfirst($url[0]) . "Controller" : null;
        $method = $_SERVER['REQUEST_METHOD'];

        // Path to controller
        $controllerPath = "../src/controllers/" . $controllerName . ".php";

        // Check if controller exists
        if ($controllerName && file_exists($controllerPath)) {
            require_once $controllerPath;
            $controller = new $controllerName();

            // Call the correct method based on HTTP request method
            switch ($method) {
                case 'GET':
                    $controller->get();
                    break;
                case 'POST':
                    $controller->post();
                    break;
                case 'PATCH':
                    $controller->patch();
                    break;
                default:
                     http_response_code(405);
                     echo json_encode(["erro" => "Method Not Allowed"]);
                     break;
            }
        } else {
            http_response_code(404);
            echo json_encode(["error" => "Endpoint Not Found"]);
        }
    }
}