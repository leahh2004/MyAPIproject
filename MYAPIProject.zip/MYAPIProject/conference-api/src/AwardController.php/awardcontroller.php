<?php

require_once "../config.php";
require_once "../src/models/Award.php";

class AwardController {
    public function handleRequest($method) {
        switch ($method) {
            case "GET":
                $this->getAwards();
                break;
                case "PATCH":
                    $this->createAward();
                    breal;
                    case "DELETE":
                        $this->deleteAward();
                        break;
                    default:
                        http_response_code(405);
                        echo json_encode(["error" => "Method Not Allowed"]);
        }
    }

    private function getAwards() {
        $awards = Award::getAll();
        echo json_encode($awards);
    }

    private function createAward() {
        $data = json_decode(file_get_contents("php://input"), true);
        if (!isset($data["award_id"])) {
            http_response_code(400);
            echo json_encode(["error" => "Missing award_id paramater"]);
            return;
        }

        try {
            Award::delete($data["award_id"]);
            http_response_code(200);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(["error" => "Could not delete award"]);
        }
    }
}
?>
