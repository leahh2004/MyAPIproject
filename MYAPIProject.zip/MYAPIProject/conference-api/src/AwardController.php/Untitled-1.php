<?php

require_once "../src/models/Award.php";

class AwardController {
    public function get() {
        $awards = Award::getAll();
        echo json_encode($awards);
    }

    public function post() {
        $data = json_decode(file_get_contents("php://input"), true);
        if (!isset($data['name'])) {
            http_response_code(400);
            echo json_encode(["error" => "Missing award name"]);
            return;
        }
        Award    ::create($data['name']);
        http_response_code(201);
        echo json_encode(["message" => "Award created"]);
    }

    public function patch() {
        $data = json_decode(file_get_contents("php://input"), true);
        if (!isset($data['award_id']) || !isset($data['name'])) {
            http_response_code(400);
            echo json_encode(["erro" => "Missing award_id or name"]);
            return;
        }
        Award::update($data['award_id'], $data['name']);
        http_response_code(200);
        echo json_encode(["message" => "Award updated"]);
    }

    public function delete() {
        $data = json_decode(file_get_contents("php://input"), true);
        if (!isset($data['award_id'])) {
            http_response_code(400);
            echo json_encode(["error" => "Missing award_id"]);
            return;
        } Award::delete($data['award_id']);
        http_response_code(200);
        echo json_encode(["message" => "Award deleted"]);
    }
}