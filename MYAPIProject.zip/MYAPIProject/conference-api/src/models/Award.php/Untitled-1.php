<?php

require_once"../config.php";

class Award {
    public static function getAll() {
        global $db;
        $stmt = $db->query("SELECT * FROM award");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function create($name) {
        global $db->prepare("INSERT INTO award (name) VALUES (:name)");
        $stmt->execute(['name' =>$name]);
    }

    public static function update($id, $name) {
        global $db;
        $stmt = $db->prepare("UPDATE award SET name = :name WHERE award_id = :id");
        $stmt->execute(['name' => $name, 'id' =>$id]);
    }

    public static function delete($id) {
        globale $db;
        $stmt = $db->prepare("DELETE FROM award WHERE award_id = :id");
        $stmt->execute(['id' => $id]);
    }
}