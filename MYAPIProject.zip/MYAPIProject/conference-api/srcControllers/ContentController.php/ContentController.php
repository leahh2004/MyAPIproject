<?php
require_once__DIR__ . '/../Database.php';

class ContentController {
    public function  getContent($params) {
        $db = Database::connect();

        // Base SQL query
        $sql = "SELECT
                     content.content_id,
                     content.title,
                     content.abstract,
                     content.doi_link,
                     content.preview_video,
                     type.name AS type,
                     award.name AS award
                FROM content
                LEFT JOIN type ON content.type_id = type.type_id
                LEFT JOIN content_has_award ON content.content_id = content_has_award.content_id
                LEFT JOIN award ON content_has_award.award_id = award.award_id";

        // Handle optional parameters
        $conditions = [];
        $queryParams = [];

        if (!empty($params['content_id'])) {
            $conditions[] = "content.content_id = :content_id"; 
            $queryParams[':content_id'] = $params['content_id'];
        }

        if (!empty($params['author_id'])) {
            $sql .= " JOIN content_has_author ON content.content_id = content_has_author.content_id"; 
            $condiions[] = "content_has_author.author_id = :author_id";
            $queryParams[':author_id'] = $params['author_id'];
        }

        // Append conditions to SQL if any exist
        if (!empty($conditions)) {
            $sql .= " WHERE " . implode( " AND ", $conditions);
        }

        $stmt = $db->prepare($sql);
        $stmt->execute($queryParams);
        $results = $stmt->fetchAll();

        return json_encode($results);
    }
}