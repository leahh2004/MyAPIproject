<?php
namespace Controllers;

use Core\Database;
use Core\Auth;
use PDO;

class AuthorController {
    public function handleRequest(string $action, array $params) {
        if (!Auth::checkApiKey()) return;

        switch ($action) {
            case 'GET':
                if (isset($params['id'])) {
                    $this->getAuthorById($params['id']);
                } elseif (isset($params['search'])) {
                    $this->searchAuthors($params['search']);
                } else {
                    $this->getAllAuthors();
                }
                break;
            default:
                http_response_code(405);
                echo json_encode(["error" => "Method not allowed"]);
        }
    }

    private function getAllAuthors() {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->query("SELECT * FROM author");
        $authors = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode($authors);
    }

    private function getAuthorById(int $id) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT * FROM author WHERE id = ?");
        $stmt->execute([$id]);
        $author = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($author) {
            echo json_encode($author);
        } else {
            http_response_code(404);
            echo json_encode(["error" => "Author not found"]);
        }
    }

    private function searchAuthors(string $query) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT * FROM author WHERE name LIKE ?");
        $stmt->execute(['%' . $query . '%']);
        $authors = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode($authors);
    }
}
