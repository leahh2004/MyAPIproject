<?php
require_once "../config.php";

try {
    $db = Database::connect();
    echo json_encode(["success" => "Database connection successful"]);
} catch (Exception $e) {
    echo (Exception $e) {
    }
}
?>