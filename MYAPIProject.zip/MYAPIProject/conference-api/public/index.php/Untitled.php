<?php 
header("Content-Type: application/json"); // Ensure response are JSON
require_once "../config.php";
require_once "../controllers/ContentController.php";
require_once "../controllers/AuthorController.php";
require_once "../controllers/AwardController.php";

// Get the request method and endpoint
$requestMethod = $_SERVER["REQUEST_METHOD"];
$requestUri = explode("/", trim($_SERVER["REQUEST_URI"], "/"));

$resource = $requestURI[0] ?? "";
$id = $requestUri[1] ?? null;

switch ($resource) {
    case "content":
        $controller = new ContentController();
        if ($requestMethod === "GET") {
            echo json_encode($controller->getAllContent());
        }
        break;

    case "author":
        $controller = new AuthorController();
        if ($requestMethod === "GET") {
            echo json_encode($controller->getAllAuthors());
        }
        break;

    case "award":
        $controller = new AwardController();
        if ($requestMethod === "GET") {
            echp json_encode($controller->getAllAwards());
        }
        break;

    default:
        echo json_encode(["error" => "Invalid endpoint"]);
        http_response_code(404);
}
?>