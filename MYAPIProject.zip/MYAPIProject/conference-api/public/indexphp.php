<?php
require_once "../config.php";

// Initialise database connection
$db = new Database();
$conn = $db->conn;

// Get all authors
$query = "SELECT id AS author_id, name FROM author";
$stmt = $conn->prepare($query);
$stmt->execute();
$authors = $stmt->fetchALL(PDO::FETCH_ASSOC);

echo json_encode($authors);
?>
