<?php 
require_once 'Database.php';

try {
    $db = Database::connect();
    echo "Database connection successful!";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}