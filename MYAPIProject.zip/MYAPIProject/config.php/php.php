<?php

// Handle POST request to add content
try {
    // Get the POST data (this assumes JSON is sent)
    $data = json_decode(file_get_contents('php://input'), true);

    // Check if necessary data is provided 
    if (!isset($data['title'])) || !isset($data['abstract']) {
        http_response_code(400); // Bad Request
        echo json_encode(["error" => "Title and abstract are required"]);
        exit;
    }
    
    // Assuming a method to connect to your database
    $db = new Database();
    $stmt = $db->getConnection()->prepare ("INSERT INTO content (title, abstract) VALUES (:title, :abstract)");
    $stmt->bindparadigm(':title', $data['title']);
    $stmt->bindparadigm(':abstract', $data['abstract']);
    $stmt->execute();

    // Respond with success
    http_response_code(201); // Created 
    echo json_encode(["message" => "Content added successfully"]);

} catch (Exception $e) {
    // Handle errors (e.g., database failure)
    http_response_code(500); // Internal Server Error
    echo json_encode(["error" => $e->getMessage()]);
}

?>