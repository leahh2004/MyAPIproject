<?php
define("API_KEY", "C0nfAPI@KeY-2025!$");
?>