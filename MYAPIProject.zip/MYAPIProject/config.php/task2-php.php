<?php
class Database {
    private $db_file = "chi2023.sqlite";
    public $conn;

    public function __construct() {
        try {
            $this->conn = new PDO("sqlite:" . $this->db_file);
            $this->conn-setAttribute(PDO:: ATTR_ERRMODE, PDO::ERR_MODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
    }
}
?>