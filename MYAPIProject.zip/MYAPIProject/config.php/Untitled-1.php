<?php 
// Database cofiguration file

class Database {
    private static $pdo = null;

    public static function connect() {
        if (self::$pdo === null) {
            try {
                // Path to SQlite database file
                $dbPath = __DIR__ . "/database/conference.db";

                // Connect to SQLite database file
                self::$pdo = new PDO("sqlite:" . $dbPath);

                // Set error mode to exceptions
                self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTIOn);
            } catch (PDOException $e) {
                die(json_encode(["error" => "database connection failed; " . $e->getMessage()]));
            }
        }
        return self::$pdo;
    }
}
?>