<?php
require_once 'endpoints/author.php'; //  Include the Author endpoint

class Router {
    public function handleRequest($request) {
        header('Content-Type: application/json');

        $parts = explode('/', trim($request, '/'));
        $endpoint = $parts[0] ?? '';

        switch ($endpoint) {
            case 'author':
                $authorHandler = new AuthorHandler();
                $authorHandler->processRequest();
                break;
            default:
                http_response_code(404);
                echo json_encode(["error" => "Endpoint not found"]);
                break;
        }
    }
}
?>