endpoints/developer.php

<?php
// Logic for the 'developer' endpoint

// Return the JSON response with your name and student ID
echo json_encode([
    "student_id" => "W23017629"
    "name" => "Leah Huckstep"
]);
?>