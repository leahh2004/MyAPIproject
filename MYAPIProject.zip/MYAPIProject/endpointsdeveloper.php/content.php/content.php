<?php 
// Include a database connection class (create this separately)
require_once '../db/Database.php';

// Get the content data from the database
try {
    $db = new Database();
    $stmt = $db->getConnection()->query('SELECT * FROM content'); // Get all content
    $contentData = $stmt->fetchALL(PDO::FETCH_ASSOC);

    // Return content data as JSON
    echo json_encode($contentData); 
} catch (exception $e) {
    // Handle any erros (e.g., database connection failures)
    http_response_code(500); // Internal Server Error
    echo json_encode(["error" => $e->getMessage()]);
}
?>