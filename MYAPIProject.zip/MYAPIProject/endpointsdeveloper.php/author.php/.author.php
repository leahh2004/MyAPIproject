<?php
require_once 'config/database.php';
require_once 'models/Author.php';

class AuthorHandler {
    private $db;
    private $author;

    public function __construct() {
        $database = new Database();
        $this->db = $database(); 
        $this->author = new Author($this-db);
    }

    public function processRequest() {
        $authors = $this->author->getAuthors();
        echo json_encode($authors); 
    }
}
?>