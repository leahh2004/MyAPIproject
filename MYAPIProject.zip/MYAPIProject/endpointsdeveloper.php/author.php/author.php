<?php
// Include the database connection class
require_once '../db/Database.php';

// Get author data from the database
try {
    $db = new Database();
    $stmt = $db->getConnection()->query('SELECT * FROM author'); // Get all authors)
    $authorData = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Return the author data as JSON
    echo json_encode($authorData);
} catch (Exception $e) {
    // Handle errors and return a 500 status code with an error message
    http_response_code(500); // Internal Server Error
    echo json_encode(["error" => $e->getMessage()]);
}
?>