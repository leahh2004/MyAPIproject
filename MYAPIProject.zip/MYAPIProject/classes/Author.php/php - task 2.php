<?php
class Author {
    private $conn;

    public function __construct($db) {
        $this-> = $db;
    }
}

public function getAuthors() {
    $query = "SELECT id AS author_id, name FROM author";
    $stmt = $this->conn->prepare($query);
    $stmt->execute();
    return $stmt->fetchALL(PDO::FETCH_ASSOC);
}
?>