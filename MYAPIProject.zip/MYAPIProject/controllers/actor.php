<?php
function handleActorRequest($method) {
    switch ($method) {
        case 'GET':
            return json_encode(["message" => "GET request received for actor"]);
        case 'POST':
            return json_encode(["message" => "POST request received for actor"]);
        case 'PATCH':
            return json_encode(["message" => "PATCH request received for actor"]);
        case 'DELETE':
            return json_encode(["message" => "DELETE request received for actor"]);
        default:
            return json_encode(["error" => "Invalid request"]);
    }
}
?>
