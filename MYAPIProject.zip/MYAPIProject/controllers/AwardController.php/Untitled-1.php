<?php
require_once "../config.php";

class AwardController {
    private $db;

    public function __construct() {
        $this->db = Database::connect();
    }

    public function getAllAwards() {
        $query = "SELECT * FROM award";
        $stmt = $this->db->query($query);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
