<?php
require_once "../config.php";

class ContentController {
    private $db;

    public function __construct() {
        $this->db = Database::connect();
    }
    
    public function getAllContent() {
        $query = "SELECT * FROM content";
        $stmt = $this->db->query($query);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>