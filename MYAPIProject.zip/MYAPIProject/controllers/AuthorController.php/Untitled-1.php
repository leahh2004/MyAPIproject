<?php
require_once "../config.php";

class AuthorController {
    private $db;

    public function __construct() {
        $this->db = Database::connect();
    }

    public function getAllAuthors() {
        $query = "SELECT * FROM author";
        $stmt = $this->db->query($query);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
